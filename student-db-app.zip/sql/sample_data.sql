USE studentdb;
INSERT INTO students (roll_no, name, email, phone, department, gpa) VALUES
('CS001', 'Alice Johnson', 'alice@example.com', '555-1010', 'CS', 3.8),
('CS002', 'Bob Smith', 'bob@example.com', '555-2020', 'CS', 3.4),
('EE101', 'Charlie Kim', 'charlie@example.com', '555-3030', 'EE', 3.6);
