package com.example.studentdb.service;

import com.example.studentdb.dao.StudentDAO;
import com.example.studentdb.model.Student;

import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

public class StudentService {

    private final StudentDAO dao;
    private static final Pattern EMAIL = Pattern.compile("^[^@\n\r]+@[^@\n\r]+\.[^@\n\r]+$");

    public StudentService(StudentDAO dao) {
        this.dao = dao;
    }

    public int addStudent(Student s) {
        validate(s, true);
        return dao.create(s);
    }

    public Optional<Student> getById(int id) { return dao.findById(id); }

    public Optional<Student> getByRollNo(String rollNo) { return dao.findByRollNo(rollNo); }

    public List<Student> getAll() { return dao.findAll(); }

    public List<Student> searchByName(String q) { return dao.searchByName(q); }

    public boolean updateStudent(Student s) {
        validate(s, false);
        return dao.update(s);
    }

    public boolean deleteStudent(int id) { return dao.delete(id); }

    private void validate(Student s, boolean creating) {
        if (s.getRollNo() == null || s.getRollNo().isBlank()) {
            throw new IllegalArgumentException("roll_no is required");
        }
        if (s.getName() == null || s.getName().isBlank()) {
            throw new IllegalArgumentException("name is required");
        }
        if (s.getEmail() != null && !s.getEmail().isBlank()
                && !EMAIL.matcher(s.getEmail()).matches()) {
            throw new IllegalArgumentException("email is not valid");
        }
        if (s.getGpa() != null && (s.getGpa() < 0.0 || s.getGpa() > 4.0)) {
            throw new IllegalArgumentException("gpa must be between 0.0 and 4.0");
        }
    }
}
