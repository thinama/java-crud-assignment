package com.example.studentdb.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Utility class for getting database connections using properties from
 * src/main/resources/db.properties
 */
public class DBUtil {
    private static final String PROPS_FILE = "db.properties";
    private static String url;
    private static String username;
    private static String password;

    static {
        try (InputStream in = DBUtil.class.getClassLoader().getResourceAsStream(PROPS_FILE)) {
            if (in == null) {
                throw new RuntimeException("Cannot find " + PROPS_FILE + " on classpath");
            }
            Properties props = new Properties();
            props.load(in);
            url = props.getProperty("url");
            username = props.getProperty("username");
            password = props.getProperty("password");

            if (url == null || username == null || password == null) {
                throw new RuntimeException("db.properties must define url, username, and password");
            }
            // Modern JDBC auto-loads drivers; explicit load left for clarity
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                // Ignore if driver autoloads
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to load DB properties", e);
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, username, password);
    }
}
