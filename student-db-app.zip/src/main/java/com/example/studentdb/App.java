package com.example.studentdb;

import com.example.studentdb.dao.StudentDAO;
import com.example.studentdb.dao.StudentDAOImpl;
import com.example.studentdb.exception.DataAccessException;
import com.example.studentdb.model.Student;
import com.example.studentdb.service.StudentService;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class App {

    private final StudentService service;
    private final Scanner scanner = new Scanner(System.in);

    public App(StudentService service) {
        this.service = service;
    }

    public static void main(String[] args) {
        StudentDAO dao = new StudentDAOImpl();
        StudentService service = new StudentService(dao);
        new App(service).run();
    }

    private void run() {
        System.out.println("=== Student Database App ===");
        while (true) {
            printMenu();
            String choice = prompt("Choose an option");
            try {
                switch (choice) {
                    case "1" -> createStudent();
                    case "2" -> listStudents();
                    case "3" -> viewStudentById();
                    case "4" -> updateStudent();
                    case "5" -> deleteStudent();
                    case "6" -> searchByName();
                    case "0" -> {
                        System.out.println("Goodbye!");
                        return;
                    }
                    default -> System.out.println("Invalid option. Try again.");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Validation error: " + e.getMessage());
            } catch (DataAccessException e) {
                System.out.println("Database error: " + e.getMessage());
                if (e.getCause() != null) System.out.println("  Cause: " + e.getCause().getMessage());
            } catch (Exception e) {
                System.out.println("Unexpected error: " + e.getMessage());
            }
        }
    }

    private void printMenu() {
        System.out.println();
        System.out.println("1) Add student");
        System.out.println("2) List all students");
        System.out.println("3) View student by ID");
        System.out.println("4) Update student");
        System.out.println("5) Delete student");
        System.out.println("6) Search by name");
        System.out.println("0) Exit");
    }

    private void createStudent() {
        System.out.println("-- Add Student --");
        String rollNo = prompt("Roll No");
        String name = prompt("Name");
        String email = prompt("Email (optional)");
        String phone = prompt("Phone (optional)");
        String department = prompt("Department (optional)");
        Double gpa = readDouble(prompt("GPA 0.0-4.0 (optional)"));

        Student s = new Student(rollNo, name, emptyToNull(email), emptyToNull(phone), emptyToNull(department), gpa);
        int id = service.addStudent(s);
        System.out.println("Created with id: " + id);
    }

    private void listStudents() {
        List<Student> list = service.getAll();
        if (list.isEmpty()) {
            System.out.println("No students found.");
            return;
        }
        System.out.println("ID | RollNo | Name | Email | Phone | Dept | GPA");
        for (Student s : list) {
            System.out.printf("%d | %s | %s | %s | %s | %s | %s%n",
                    s.getId(), s.getRollNo(), s.getName(),
                    nullToDash(s.getEmail()), nullToDash(s.getPhone()),
                    nullToDash(s.getDepartment()), s.getGpa()==null?"-":String.format("%.2f", s.getGpa()));
        }
    }

    private void viewStudentById() {
        int id = Integer.parseInt(prompt("Enter ID"));
        Optional<Student> opt = service.getById(id);
        if (opt.isPresent()) {
            System.out.println(opt.get());
        } else {
            System.out.println("Not found.");
        }
    }

    private void updateStudent() {
        System.out.println("-- Update Student --");
        int id = Integer.parseInt(prompt("ID"));
        Optional<Student> existing = service.getById(id);
        if (existing.isEmpty()) {
            System.out.println("Student not found.");
            return;
        }
        Student cur = existing.get();
        System.out.println("Leave field blank to keep current value.");
        String rollNo = defaultIfBlank(prompt("Roll No (" + cur.getRollNo() + ")"), cur.getRollNo());
        String name = defaultIfBlank(prompt("Name (" + cur.getName() + ")"), cur.getName());
        String email = defaultIfBlank(prompt("Email (" + nullToDash(cur.getEmail()) + ")"), cur.getEmail());
        String phone = defaultIfBlank(prompt("Phone (" + nullToDash(cur.getPhone()) + ")"), cur.getPhone());
        String dept = defaultIfBlank(prompt("Department (" + nullToDash(cur.getDepartment()) + ")"), cur.getDepartment());
        String gpaStr = prompt("GPA (" + (cur.getGpa()==null?"-":cur.getGpa()) + ")");
        Double gpa = gpaStr.isBlank() ? cur.getGpa() : readDouble(gpaStr);

        Student s = new Student(id, rollNo, name, emptyToNull(email), emptyToNull(phone), emptyToNull(dept), gpa);
        boolean ok = service.updateStudent(s);
        System.out.println(ok ? "Updated." : "No changes.");
    }

    private void deleteStudent() {
        int id = Integer.parseInt(prompt("ID to delete"));
        boolean ok = service.deleteStudent(id);
        System.out.println(ok ? "Deleted." : "Not found.");
    }

    private void searchByName() {
        String q = prompt("Name contains");
        List<Student> list = service.searchByName(q);
        if (list.isEmpty()) {
            System.out.println("No match.");
            return;
        }
        list.forEach(System.out::println);
    }

    private String prompt(String label) {
        System.out.print(label + ": ");
        return scanner.nextLine().trim();
    }

    private Double readDouble(String input) {
        if (input == null || input.isBlank()) return null;
        try {
            return Double.parseDouble(input);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Not a number: " + input);
        }
    }

    private String defaultIfBlank(String val, String def) { return (val == null || val.isBlank()) ? def : val; }
    private String emptyToNull(String s) { return (s == null || s.isBlank()) ? null : s; }
    private String nullToDash(String s) { return s == null ? "-" : s; }
}
