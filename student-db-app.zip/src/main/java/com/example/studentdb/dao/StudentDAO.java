package com.example.studentdb.dao;

import com.example.studentdb.model.Student;
import java.util.List;
import java.util.Optional;

public interface StudentDAO {
    int create(Student s);
    Optional<Student> findById(int id);
    Optional<Student> findByRollNo(String rollNo);
    List<Student> findAll();
    List<Student> searchByName(String nameQuery);
    boolean update(Student s);
    boolean delete(int id);
}
